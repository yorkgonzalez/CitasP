package com.example.citasmedicas.model;

import jakarta.persistence.*;

import jakarta.persistence.GeneratedValue;

@Entity
@Table(name = "medico")
public class Medico {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String nombre;
	private String especialidad;
	private String telefono;
	private String correo;
	

	public Medico(Long id, String nombre, String especialidad, String telefono, String correo) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.especialidad = especialidad;
		this.telefono = telefono;
		this.correo = correo;
		
	}

	public Medico() {
		// TODO Auto-generated constructor stub
	}

	// Getters y Setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}

}
