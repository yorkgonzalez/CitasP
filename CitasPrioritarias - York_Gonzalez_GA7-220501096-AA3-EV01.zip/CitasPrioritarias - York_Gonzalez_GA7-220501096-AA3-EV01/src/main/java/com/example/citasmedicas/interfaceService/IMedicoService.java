package com.example.citasmedicas.interfaceService;

import java.util.List;

import com.example.citasmedicas.model.Medico;

public interface IMedicoService {
	 public List<Medico> listar();

}



