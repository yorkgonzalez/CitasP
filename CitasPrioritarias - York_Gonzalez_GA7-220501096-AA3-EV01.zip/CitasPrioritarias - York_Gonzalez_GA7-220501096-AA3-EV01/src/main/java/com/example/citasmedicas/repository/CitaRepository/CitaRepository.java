package com.example.citasmedicas.repository.CitaRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.citasmedicas.model.Cita.Cita;

@Repository
public interface CitaRepository extends JpaRepository<Cita, Long> {
	List<Cita> findByUsuarioId(Long usuarioId);

	List<Cita> findByUsuarioUsername(String username);
}


    